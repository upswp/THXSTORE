<template>
  <div class="userstore-live-container">
    라이브가 시작되요 Lorem ipsum dolor sit amet consectetur adipisicing elit. In enim obcaecati iste voluptatum impedit
    magnam rerum corporis dicta esse amet, omnis aperiam aut suscipit deserunt et quibusdam eum sit beatae.
    <button @click="forDongSik">동식이 버튼</button>
  </div>
</template>

<script>
import { getLiveCommerce } from '@/api/userStore';
export default {
  methods: {
    async forDongSik() {
      const result = await getLiveCommerce();
      console.log(result);
    },
  },
};
</script>

<style lang="scss" scoped>
.userstore-live-container {
  width: 100%;
}
</style>
