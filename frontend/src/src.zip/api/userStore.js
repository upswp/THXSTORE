import { createInstance, createInstanceWithToken } from '@/api';

const publicAPI = createInstance('api/store/');
const privateAPI = createInstanceWithToken('api/store/');

const getStoreInfo = storeId =>
  publicAPI.get('info/', {
    params: {
      storeId: storeId,
    },
  });

const getStoreMenu = storeId =>
  publicAPI.get('user/product/', {
    params: {
      storeId: storeId,
    },
  });

const getStoreTimedeal = storeId => privateAPI.get(`timedeal/${storeId}`);

// ==================================

// const DongSikAPI = createInstance('https://k4b202.p.ssafy.io <= 이 주소 뒤에 오는 URL을 아래와 같이 넣으면 됨');
const DongSikAPI = createInstance('api/store/');

//  https://k4b202.p.ssafy.io/
const getLiveCommerce = () => {};
// DongSikAPI.get('여기에는 body나 params가 들어가는 곳;
DongSikAPI.get('여기에 주소적으면 됨(');

export { getStoreInfo, getStoreMenu, getStoreTimedeal, getLiveCommerce };
