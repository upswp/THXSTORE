export function handleException(error) {
  console.log(error);
}
